# Urbanion's SpookyCraft (Forge 1.20.1)

## Build the JAR without installing anything (GitHub Actions)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder, including the hidden `.github` folder
   (if drag-and-drop skips it: Add file > Create new file, name it `.github/workflows/build.yml`, paste the contents).
3. Open the **Actions** tab, wait for "Build mod JAR" to finish (first run takes a few minutes).
4. Click the finished run, download **spookycraft-jar** under Artifacts, unzip it, and put the .jar in your `mods` folder.
(You can also start a build by hand with "Run workflow".)

## Build the JAR on your own PC
1. Install JDK 17.
2. Download the Forge **1.20.1 MDK** (files.minecraftforge.net, version 47.x) and copy these from it into this folder:
   `gradlew`, `gradlew.bat` and the `gradle/` folder (the Gradle wrapper).
3. In this folder run:  `./gradlew build`   (Windows: `gradlew.bat build`)
4. Your mod is in `build/libs/spookycraft-1.0.0.jar` -> put it in your `.minecraft/mods` folder (Forge 1.20.1).

To test without building a JAR: `./gradlew runClient`

## What's inside
- Main menu: vanilla logo textures are replaced by transparent ones; `client/TitleScreenHandler` draws
  "Urbanion's SpookyCraft" with the Minecraft font (orange, purple outline).
- Doorbell block (`block/DoorbellBlock`) + auto-placement next to village doors (`event/VillageDoorbells`).
- Trick or Treat logic: `event/DoorbellHandler` (ringing) and `event/VisitManager` (villager walks to door, opens it, 50/50).
- Candy: `init/ModItems`.
- Replace `assets/spookycraft/sounds/doorbell.ogg` (mono OGG) to change the doorbell sound.

## Testing the new stuff in-game
- Find a town: `/locate structure spookycraft:trick_or_treat_town`  (only generates in NEW chunks; to test in an old world stand somewhere flat and run `/place structure spookycraft:trick_or_treat_town`)
- Trick or treating only works from dusk to dawn: `/time set 13000`
- Spawn eggs and masks are in the creative tab "Urbanion's SpookyCraft"
- UI theme can be turned off in `config/spookycraft-client.toml` (uiTheme = false)
- If doorbells in normal villages misbehave, enable debug logging for the mod and check `logs/latest.log`
