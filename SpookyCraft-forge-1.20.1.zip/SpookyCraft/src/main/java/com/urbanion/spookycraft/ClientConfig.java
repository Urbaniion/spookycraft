package com.urbanion.spookycraft;

import net.minecraftforge.common.ForgeConfigSpec;

public class ClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue UI_THEME;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        UI_THEME = builder
                .comment("Recolor menus and GUIs to orange and purple. Set to false to get the normal look back.")
                .define("uiTheme", true);
        SPEC = builder.build();
    }
}
