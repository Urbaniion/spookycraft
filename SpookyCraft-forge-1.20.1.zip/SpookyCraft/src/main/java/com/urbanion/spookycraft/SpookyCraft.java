package com.urbanion.spookycraft;

import com.mojang.logging.LogUtils;
import com.urbanion.spookycraft.init.ModBlocks;
import com.urbanion.spookycraft.init.ModEntities;
import com.urbanion.spookycraft.init.ModItems;
import com.urbanion.spookycraft.init.ModSounds;
import com.urbanion.spookycraft.init.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(SpookyCraft.MODID)
public class SpookyCraft {
    public static final String MODID = "spookycraft";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SpookyCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }
}
