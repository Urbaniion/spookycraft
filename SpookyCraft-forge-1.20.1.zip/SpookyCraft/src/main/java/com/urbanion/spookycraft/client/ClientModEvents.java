package com.urbanion.spookycraft.client;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.init.ModEntities;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpookyCraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final ModelLayerLocation WEREWOLF_LAYER =
            new ModelLayerLocation(new ResourceLocation(SpookyCraft.MODID, "werewolf"), "main");

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.TRICK_OR_TREAT_VILLAGER.get(), TrickOrTreatVillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.WEREWOLF.get(), WerewolfRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(WEREWOLF_LAYER, WerewolfModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener(new UiThemeReloadListener());
    }
}
