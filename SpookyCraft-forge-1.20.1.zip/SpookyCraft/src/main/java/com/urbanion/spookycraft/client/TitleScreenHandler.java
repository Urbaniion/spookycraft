package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The vanilla logo textures are replaced with transparent ones (see resources),
 * and this draws "Urbanion's SpookyCraft" with the real Minecraft font instead:
 * orange fill, purple outline.
 */
@Mod.EventBusSubscriber(modid = SpookyCraft.MODID, value = Dist.CLIENT)
public class TitleScreenHandler {
    private static final String TITLE = "Urbanion's SpookyCraft";
    private static final int ORANGE = 0xFFFF8A00;
    private static final int PURPLE = 0xFF5B1A9E;

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof TitleScreen screen)) {
            return;
        }
        GuiGraphics graphics = event.getGuiGraphics();
        Font font = Minecraft.getInstance().font;

        int textWidth = font.width(TITLE);
        float scale = Math.min(3.0F, (screen.width * 0.85F) / textWidth);
        float x = (screen.width - textWidth * scale) / 2.0F;
        float y = 30.0F + (44.0F - 8.0F * scale) / 2.0F; // vertically centred where the logo used to be

        PoseStack pose = graphics.pose();
        pose.pushPose();
        pose.translate(x, y, 0.0F);
        pose.scale(scale, scale, 1.0F);

        // purple outline: draw the text shifted in all 8 directions
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) {
                    graphics.drawString(font, TITLE, dx, dy, PURPLE, false);
                }
            }
        }
        // orange text on top
        graphics.drawString(font, TITLE, 0, 0, ORANGE, false);

        pose.popPose();
    }
}
