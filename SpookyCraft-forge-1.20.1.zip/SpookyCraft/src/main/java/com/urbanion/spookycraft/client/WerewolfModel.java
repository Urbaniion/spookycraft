package com.urbanion.spookycraft.client;

import com.urbanion.spookycraft.entity.Werewolf;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Humanoid body with a wolf snout and pointy ears on the head. Texture is 64x64. */
public class WerewolfModel extends HumanoidModel<Werewolf> {
    public WerewolfModel(ModelPart root) {
        super(root);
        this.hat.visible = false; // the hat UV area is used for the snout and ears
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.getChild("head");
        head.addOrReplaceChild("snout",
                CubeListBuilder.create().texOffs(32, 0).addBox(-2.0F, -3.0F, -7.0F, 4.0F, 3.0F, 3.0F),
                PartPose.ZERO);
        head.addOrReplaceChild("ear_left",
                CubeListBuilder.create().texOffs(48, 0).addBox(1.5F, -11.0F, -1.0F, 2.0F, 3.0F, 1.0F),
                PartPose.ZERO);
        head.addOrReplaceChild("ear_right",
                CubeListBuilder.create().texOffs(48, 0).addBox(-3.5F, -11.0F, -1.0F, 2.0F, 3.0F, 1.0F),
                PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(Werewolf entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entity.isAggressive(), this.attackTime, ageInTicks);
    }
}
