package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.Werewolf;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class WerewolfRenderer extends MobRenderer<Werewolf, WerewolfModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SpookyCraft.MODID, "textures/entity/werewolf/werewolf.png");
    private static final ResourceLocation EYES =
            new ResourceLocation(SpookyCraft.MODID, "textures/entity/werewolf/werewolf_eyes.png");

    public WerewolfRenderer(EntityRendererProvider.Context context) {
        super(context, new WerewolfModel(context.bakeLayer(ClientModEvents.WEREWOLF_LAYER)), 0.6F);
        addLayer(new GlowingEyes(this));
    }

    @Override
    public ResourceLocation getTextureLocation(Werewolf entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(Werewolf entity, PoseStack pose, float partialTick) {
        pose.scale(1.2F, 1.2F, 1.2F);
    }

    private static class GlowingEyes extends EyesLayer<Werewolf, WerewolfModel> {
        GlowingEyes(RenderLayerParent<Werewolf, WerewolfModel> parent) {
            super(parent);
        }

        @Override
        public RenderType renderType() {
            return RenderType.eyes(EYES);
        }
    }
}
