package com.urbanion.spookycraft.event;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.block.DoorbellBlock;
import com.urbanion.spookycraft.data.DoorbellSavedData;
import com.urbanion.spookycraft.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Adds a doorbell next to the (outside of the) door of wooden village doors that come
 * close to a player. Works for new AND already generated vanilla villages.
 * (Trick or Treat Town houses already contain their doorbells.)
 */
@Mod.EventBusSubscriber(modid = SpookyCraft.MODID)
public class VillageDoorbells {
    private static final TagKey<Structure> VILLAGE =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation("minecraft", "village"));

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (player.tickCount % 100 != 0) { // every 5 seconds
            return;
        }
        ServerLevel level = player.serverLevel();
        DoorbellSavedData data = DoorbellSavedData.get(level);
        BlockPos center = player.blockPosition();
        int placed = 0;

        for (BlockPos scan : BlockPos.betweenClosed(center.offset(-24, -8, -24), center.offset(24, 8, 24))) {
            if (placed >= 6) {
                break;
            }
            if (!level.hasChunkAt(scan)) {
                continue;
            }
            BlockState state = level.getBlockState(scan);
            if (!state.is(BlockTags.WOODEN_DOORS) || !state.hasProperty(DoorBlock.HALF)
                    || state.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) {
                continue;
            }
            BlockPos doorPos = scan.immutable();
            if (data.isDone(doorPos)) {
                continue;
            }
            if (!isVillageDoor(level, doorPos)) {
                continue;
            }
            Direction out = findOutside(level, doorPos, state.getValue(DoorBlock.FACING));
            if (out == null) {
                continue; // can't tell inside from outside (yet)
            }
            data.markDone(doorPos);
            if (hasDoorbellNear(level, doorPos)) {
                continue;
            }
            if (placeDoorbell(level, doorPos, out)) {
                placed++;
            }
        }
    }

    private static boolean isVillageDoor(ServerLevel level, BlockPos doorPos) {
        StructureStart start = level.structureManager().getStructureWithPieceAt(doorPos, VILLAGE);
        if (start.isValid()) {
            return true;
        }
        // fallback (e.g. modded villages): a villager lives close to the door
        return !level.getEntitiesOfClass(Villager.class, new AABB(doorPos).inflate(10.0D, 4.0D, 10.0D)).isEmpty();
    }

    private static boolean hasDoorbellNear(ServerLevel level, BlockPos doorPos) {
        for (BlockPos p : BlockPos.betweenClosed(doorPos.offset(-2, 0, -2), doorPos.offset(2, 2, 2))) {
            if (level.getBlockState(p).is(ModBlocks.DOORBELL.get())) {
                return true;
            }
        }
        return false;
    }

    private static boolean placeDoorbell(ServerLevel level, BlockPos doorPos, Direction out) {
        BlockState bell = ModBlocks.DOORBELL.get().defaultBlockState().setValue(DoorbellBlock.FACING, out);
        for (Direction side : new Direction[]{out.getClockWise(), out.getCounterClockWise()}) {
            BlockPos bellPos = doorPos.relative(out).relative(side).above();
            if (level.getBlockState(bellPos).isAir() && bell.canSurvive(level, bellPos)) {
                level.setBlock(bellPos, bell, 3);
                SpookyCraft.LOGGER.debug("Placed doorbell at {}", bellPos);
                return true;
            }
        }
        return false;
    }

    /**
     * The side of the door that is open to the sky is the outside; the roofed side is the inside.
     * If that doesn't decide it, the side with a ceiling right above is the inside.
     */
    public static Direction findOutside(ServerLevel level, BlockPos doorPos, Direction facing) {
        Direction other = facing.getOpposite();
        BlockPos a = doorPos.relative(facing);
        BlockPos b = doorPos.relative(other);
        boolean skyA = openToSky(level, a);
        boolean skyB = openToSky(level, b);
        if (skyA != skyB) {
            return skyA ? facing : other;
        }
        boolean roofA = hasCeiling(level, a);
        boolean roofB = hasCeiling(level, b);
        if (roofA != roofB) {
            return roofA ? other : facing;
        }
        return null;
    }

    public static boolean openToSky(ServerLevel level, BlockPos pos) {
        return pos.getY() >= level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, pos.getX(), pos.getZ());
    }

    private static boolean hasCeiling(ServerLevel level, BlockPos pos) {
        for (int dy = 1; dy <= 6; dy++) {
            if (level.getBlockState(pos.above(dy)).blocksMotion()) {
                return true;
            }
        }
        return false;
    }
}
