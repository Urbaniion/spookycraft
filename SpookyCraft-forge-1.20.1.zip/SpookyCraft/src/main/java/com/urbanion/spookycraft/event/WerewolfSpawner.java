package com.urbanion.spookycraft.event;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.Werewolf;
import com.urbanion.spookycraft.init.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/** At night, werewolves show up around players that are in or next to a Trick or Treat Town. */
@Mod.EventBusSubscriber(modid = SpookyCraft.MODID)
public class WerewolfSpawner {
    private static final TagKey<Structure> TOWN =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(SpookyCraft.MODID, "trick_or_treat_town"));

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (player.tickCount % 200 != 0) { // every 10 seconds
            return;
        }
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD || level.isDay()) {
            return;
        }
        if (!isNearTown(level, player.blockPosition())) {
            return;
        }
        if (level.random.nextFloat() > 0.35F) {
            return;
        }
        List<Werewolf> existing = level.getEntitiesOfClass(Werewolf.class, player.getBoundingBox().inflate(64.0D));
        if (existing.size() >= 2) {
            return;
        }

        double angle = level.random.nextDouble() * Math.PI * 2.0D;
        double dist = 18.0D + level.random.nextDouble() * 12.0D;
        int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
        int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
        if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
            return;
        }
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);

        Werewolf wolf = ModEntities.WEREWOLF.get().create(level);
        if (wolf == null) {
            return;
        }
        wolf.moveTo(x + 0.5D, y, z + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        if (!level.noCollision(wolf)) {
            return;
        }
        wolf.finalizeSpawn(level, level.getCurrentDifficultyAt(wolf.blockPosition()), MobSpawnType.EVENT, null, null);
        level.addFreshEntity(wolf);
    }

    private static boolean isNearTown(ServerLevel level, BlockPos pos) {
        int[][] offsets = {{0, 0}, {24, 0}, {-24, 0}, {0, 24}, {0, -24}};
        for (int[] o : offsets) {
            BlockPos p = pos.offset(o[0], 0, o[1]);
            if (level.hasChunkAt(p) && level.structureManager().getStructureWithPieceAt(p, TOWN).isValid()) {
                return true;
            }
        }
        return false;
    }
}
