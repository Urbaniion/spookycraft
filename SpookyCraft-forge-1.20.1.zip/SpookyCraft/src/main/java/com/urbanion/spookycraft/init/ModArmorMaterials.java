package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** One material per mask (the name decides which armor texture is used). Each gives 2 armor points. */
public enum ModArmorMaterials implements ArmorMaterial {
    DALLAS("dallas"),
    WOLF("wolf"),
    HOUSTON("houston"),
    HOXTON("hoxton"),
    CHAINS("chains");

    private final String name;

    ModArmorMaterials(String name) {
        this.name = name;
    }

    public String maskName() {
        return name;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return 165;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return type == ArmorItem.Type.HELMET ? 2 : 0;
    }

    @Override
    public int getEnchantmentValue() {
        return 12;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_GENERIC;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    @Override
    public String getName() {
        return SpookyCraft.MODID + ":mask_" + name;
    }

    @Override
    public float getToughness() {
        return 0.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0F;
    }
}
