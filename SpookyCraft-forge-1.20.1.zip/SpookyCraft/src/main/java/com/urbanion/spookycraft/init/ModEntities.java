package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.TrickOrTreatVillager;
import com.urbanion.spookycraft.entity.Werewolf;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = SpookyCraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SpookyCraft.MODID);

    public static final RegistryObject<EntityType<TrickOrTreatVillager>> TRICK_OR_TREAT_VILLAGER =
            ENTITIES.register("trick_or_treat_villager",
                    () -> EntityType.Builder.of(TrickOrTreatVillager::new, MobCategory.CREATURE)
                            .sized(0.6F, 1.95F)
                            .clientTrackingRange(10)
                            .build("trick_or_treat_villager"));

    public static final RegistryObject<EntityType<Werewolf>> WEREWOLF =
            ENTITIES.register("werewolf",
                    () -> EntityType.Builder.of(Werewolf::new, MobCategory.MONSTER)
                            .sized(0.7F, 2.2F)
                            .clientTrackingRange(10)
                            .build("werewolf"));

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(TRICK_OR_TREAT_VILLAGER.get(), TrickOrTreatVillager.createAttributes().build());
        event.put(WEREWOLF.get(), Werewolf.createAttributes().build());
    }
}
