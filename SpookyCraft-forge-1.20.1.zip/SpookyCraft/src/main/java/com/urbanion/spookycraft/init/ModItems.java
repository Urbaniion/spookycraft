package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.item.MaskItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpookyCraft.MODID);

    public static final RegistryObject<Item> DOORBELL = ITEMS.register("doorbell",
            () -> new BlockItem(ModBlocks.DOORBELL.get(), new Item.Properties()));

    // Candy Corn: 2 hunger bars (4 points), Regeneration II for 10 seconds
    public static final RegistryObject<Item> CANDY_CORN = ITEMS.register("candy_corn",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(4)
                    .saturationMod(0.3F)
                    .alwaysEat()
                    .fast()
                    .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 10 * 20, 1), 1.0F)
                    .build())));

    // Chocolate Bar: 3 hunger bars (6 points), Speed II for 5 seconds
    public static final RegistryObject<Item> CHOCOLATE_BAR = ITEMS.register("chocolate_bar",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(6)
                    .saturationMod(0.3F)
                    .alwaysEat()
                    .fast()
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5 * 20, 1), 1.0F)
                    .build())));

    // Lollipop: 1 hunger bar (2 points), Saturation for 10 seconds
    public static final RegistryObject<Item> LOLLIPOP = ITEMS.register("lollipop",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(2)
                    .saturationMod(0.3F)
                    .alwaysEat()
                    .fast()
                    .effect(() -> new MobEffectInstance(MobEffects.SATURATION, 10 * 20, 0), 1.0F)
                    .build())));

    // Masks (helmet slot, 2 armor points, +15% Treat chance)
    public static final RegistryObject<Item> MASK_DALLAS = ITEMS.register("mask_dallas",
            () -> new MaskItem(ModArmorMaterials.DALLAS));
    public static final RegistryObject<Item> MASK_WOLF = ITEMS.register("mask_wolf",
            () -> new MaskItem(ModArmorMaterials.WOLF));
    public static final RegistryObject<Item> MASK_HOUSTON = ITEMS.register("mask_houston",
            () -> new MaskItem(ModArmorMaterials.HOUSTON));
    public static final RegistryObject<Item> MASK_HOXTON = ITEMS.register("mask_hoxton",
            () -> new MaskItem(ModArmorMaterials.HOXTON));
    public static final RegistryObject<Item> MASK_CHAINS = ITEMS.register("mask_chains",
            () -> new MaskItem(ModArmorMaterials.CHAINS));

    @SuppressWarnings("unchecked")
    public static RegistryObject<Item>[] masks() {
        return new RegistryObject[]{MASK_DALLAS, MASK_WOLF, MASK_HOUSTON, MASK_HOXTON, MASK_CHAINS};
    }

    // Spawn eggs
    public static final RegistryObject<Item> TRICK_OR_TREAT_VILLAGER_SPAWN_EGG = ITEMS.register(
            "trick_or_treat_villager_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TRICK_OR_TREAT_VILLAGER, 0xFF8A00, 0x5B1A9E, new Item.Properties()));
    public static final RegistryObject<Item> WEREWOLF_SPAWN_EGG = ITEMS.register(
            "werewolf_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WEREWOLF, 0x4A3526, 0xFFD23F, new Item.Properties()));
}
