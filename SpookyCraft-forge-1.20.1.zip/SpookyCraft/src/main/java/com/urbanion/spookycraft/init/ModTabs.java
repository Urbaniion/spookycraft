package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SpookyCraft.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.spookycraft"))
                    .icon(() -> new ItemStack(ModItems.CANDY_CORN.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.DOORBELL.get());
                        output.accept(ModItems.CANDY_CORN.get());
                        output.accept(ModItems.CHOCOLATE_BAR.get());
                        output.accept(ModItems.LOLLIPOP.get());
                        output.accept(ModItems.MASK_DALLAS.get());
                        output.accept(ModItems.MASK_WOLF.get());
                        output.accept(ModItems.MASK_HOUSTON.get());
                        output.accept(ModItems.MASK_HOXTON.get());
                        output.accept(ModItems.MASK_CHAINS.get());
                        output.accept(ModItems.TRICK_OR_TREAT_VILLAGER_SPAWN_EGG.get());
                        output.accept(ModItems.WEREWOLF_SPAWN_EGG.get());
                    })
                    .build());
}
