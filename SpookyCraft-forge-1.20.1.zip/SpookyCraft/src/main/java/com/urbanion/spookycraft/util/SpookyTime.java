package com.urbanion.spookycraft.util;

import net.minecraft.world.level.Level;

public class SpookyTime {
    /** Trick or treating works from dusk until just before dawn. */
    public static boolean isTrickOrTreatTime(Level level) {
        long t = level.getDayTime() % 24000L;
        return t >= 11500L && t < 23500L;
    }

    /** Costumed villagers start walking home a little earlier so they are inside when it gets dark. */
    public static boolean isGoHomeTime(Level level) {
        long t = level.getDayTime() % 24000L;
        return t >= 10500L && t < 23500L;
    }
}
